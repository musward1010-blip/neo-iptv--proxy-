import { useState } from "react";

export default function NeoIPTV() {
  const [m3uUrl, setM3uUrl] = useState("");
  const [m3uFile, setM3uFile] = useState(null);
  const [step, setStep] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState("");

  const handleFileChange = (e) => setM3uFile(e.target.files[0]);
  const handleContinue = () => { if (m3uUrl || m3uFile) setStep(2); else alert("Veuillez entrer une URL ou choisir un fichier M3U"); };
  const handleCategorySelect = (category) => { setSelectedCategory(category); alert(`Vous avez choisi: ${category}`); };
  const handleBack = () => setStep(step - 1);

  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      {step === 1 && <div>
        <h2># Neo IPTV</h2>
        <div><label>Adresse M3U : <input type="text" value={m3uUrl} onChange={(e)=>setM3uUrl(e.target.value)} placeholder="https://exemple.com/playlist.m3u" /></label></div>
        <div><label>Ou fichier M3U : <input type="file" accept=".m3u,.m3u8" onChange={handleFileChange} /></label></div>
        <button onClick={handleContinue}>Continuer</button>
      </div>}
      {step === 2 && <div>
        <h3>## Choisissez une catégorie</h3>
        <div style={{ display: "flex", gap: "10px", margin: "20px 0" }}>
          <button onClick={()=>handleCategorySelect("TV en direct")}>📺 TV en direct</button>
          <button onClick={()=>handleCategorySelect("Films")}>🎬 Films</button>
          <button onClick={()=>handleCategorySelect("Séries")}>🎞️ Séries</button>
        </div>
        <button onClick={handleBack}>← Retour</button>
      </div>}
    </div>
  );
}
